package com.example.firstname;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText firstname,lastname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstname=findViewById(R.id.editTextFirstName);
        lastname=findViewById(R.id.editTextLastName);
    }

    public void ClickHereFunction(View view) {
        String fname,lname,fullname;
        fname=firstname.getText().toString();
        lname=lastname.getText().toString();
        fullname=fname +""+lname;
        Toast.makeText(this, "fullname"+fullname, Toast.LENGTH_SHORT).show();

    }
}