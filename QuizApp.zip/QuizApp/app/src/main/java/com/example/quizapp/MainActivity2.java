package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;

public class MainActivity2 extends AppCompatActivity {

    int totalmarks=0;
    RadioGroup radioGroup3, radioGroup4;
    final  static  String TotalmarksData="From second activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent myintent= getIntent();
        totalmarks= myintent.getIntExtra(MainActivity2.TotalmarksData,0);
        radioGroup3=findViewById(R.id.question3RadioGroupID);
        radioGroup4=findViewById(R.id.question4RadioGroupID);
    }

    public void PreviousFuction(View view) {
        Intent myIntent=new Intent(this,MainActivity.class);
        startActivity(myIntent);
    }

    public void finalSubmission(View view) {
        if(radioGroup3.getCheckedRadioButtonId()==R.id.quiz3option1){
            totalmarks+=2;
        }
        if(radioGroup4.getCheckedRadioButtonId()==R.id.quiz4option3){
            totalmarks+=2;
        }
        Intent myIntent= new Intent(this,MainActivity3.class);
        myIntent.putExtra(TotalmarksData,totalmarks);
        startActivity(myIntent);

    }
}