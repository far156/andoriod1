package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    TextView resultview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        resultview=findViewById(R.id.resultID);
        Intent intent=getIntent();
        int number=intent.getIntExtra(MainActivity2.TotalmarksData,0);
        resultview.setText("You got " +number+ " out of 8");
    }

    public void tryAgainFunction(View view) {
        Intent myIntent= new Intent( this, MainActivity.class);
        startActivity(myIntent);
    }
    

    public void finalSubmission(View view) {

    }

    public void PreviousFuction(View view) {
        Intent myIntent=new Intent(this,MainActivity.class);
    }
}