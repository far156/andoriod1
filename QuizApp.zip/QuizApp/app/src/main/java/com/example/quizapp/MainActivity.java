package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;

import static com.example.quizapp.MainActivity2.TotalmarksData;

public class MainActivity extends AppCompatActivity {

    RadioGroup myRadionGroup1,myRadionGroup2;
    static String MarksData="From activity 1";
    int marks=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent myintent= getIntent();
        MarksData = TotalmarksData;
        marks= myintent.getIntExtra(MarksData,0);
        myRadionGroup1=findViewById(R.id.question1RadioGroupID);
        myRadionGroup2=findViewById(R.id.question2RadioGroupID);
    }

    public void FirstFunction(View view) {

        if(myRadionGroup1.getCheckedRadioButtonId()==R.id.quiz1option1)
        {
            marks+=2;
        }
        if (myRadionGroup2.getCheckedRadioButtonId()==R.id.quiz2option2){
            marks+=2;
        }
        Intent myIntent=new Intent(this,MainActivity2.class);
        myIntent.putExtra(MarksData,marks);
        startActivity(myIntent);

    }


    public void SubmitFunction(View view) {
        if(myRadionGroup1.getCheckedRadioButtonId()==R.id.quiz1option1)
        {
            marks+=2;
        }
        if (myRadionGroup2.getCheckedRadioButtonId()==R.id.quiz2option2){
            marks+=2;
        }
        Intent myIntent=new Intent(this,MainActivity3.class);
        myIntent.putExtra(MarksData,marks);
        startActivity(myIntent);
    }
}