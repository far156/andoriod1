package com.example.mycalculator;

import androidx.appcompat.app.AppCompatActivity;


import android.view.View;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    TextView result;
    num1,num2,result;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result=(TextView)findViewById(R.id.tv1);
    }
    public void clear(View view){
        result.setText("");

    }
    public void backspace(View view){
        result.setText("");
        if(s.length() !0);{
            s=s.substring(0,0-length() -1};
        }

    }



    public void numone(View view){
        String s=result.getText().tostring();
        result.setText("s+1");
    }
    public void numtwo(View view){
        String s=result.getText().tostring();
        result.setText("s+2");
    }public void numthree(View view){
        String s=result.getText().tostring();
        result.setText("s+3");
    }public void numfour(View view){
        String s=result.getText().tostring();
        result.setText("s+4");
    }
    public void numfive(View view){
        String s=result.getText().tostring();
        result.setText("s+5");
    }
    public void numsix(View view){
        String s=result.getText().tostring();
        result.setText("s+6");
    }
    public void numseven(View view){
        String s=result.getText().tostring();
        result.setText("s+7");
    }
    public void numeight(View view){
        String s=result.getText().tostring();
        result.setText("s+8");
    }
    public void numnine(View view){
        String s=result.getText().tostring();
        result.setText("s+9");
    }
    public void numzero(View view){
        String s=result.getText().tostring();
        if (s.length()!0);
        result.setText("s+0");
    }
    public void sum(View view){
        String s=result.getText().tostring();
        num1=double.parsedouble(s);
        result.settext("");
        c=("+")
    }
    public void sum(View view){
        String s=result.getText().tostring();
        num1=double.parsedouble(s);
        result.settext("");
        c=("-");
    }
    public void sub(View view){
        String s=result.getText().tostring();
        num1=double.parsedouble(s);
        result.settext("");
        c=("-");
    }
    public void mul(View view){
        String s=result.getText().tostring();
        num1=double.parsedouble(s);
        result.settext("");
        c=("*");
    }
    public void div(View view){
        String s=result.getText().tostring();
        num1=double.parsedouble(s);
        result.settext("");
        c=("/");
    }



}