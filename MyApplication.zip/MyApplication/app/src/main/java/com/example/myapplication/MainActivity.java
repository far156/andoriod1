package com.example.myapplication;



import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //TextView mainTextview,secondview;
    //double firstnum,secondnum;
    //String operator;
    TextView primaryview, secondaryview;
    //+- korar jonno
    double num1,num2,result;
    String temp;
    String operator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        primaryview=findViewById(R.id.primaryTextview);
        secondaryview=findViewById(R.id.secondaryTextviewid);
    }

    /*public void btn1(View view) {
        String primaryValue=mainTextview.getText().toString();
        if (primaryValue.equals("0")){
            mainTextview.setText("1");
        }
        else{
            mainTextview.setText(""+primaryValue+"1");
        }
        //mainTextview.setText("1");
    }

    public void clear(View view) {
        mainTextview.setText("0");
        secondview.setText("");
    }

    public void btnSum(View view) {
        String primaryValue=mainTextview.getText().toString();
        operator="+";
        secondview.setText(""+primaryValue+operator);
        firstnum=Double.parseDouble(primaryValue);
        //btnsum btn e click korle mainview null kore dibo tahole 11+11 korle 11 kete abar new 11 asbe
        mainTextview.setText("");
    }
//= er jonno
    public void result(View view) {
        if (operator.equals("+")){
            //equal dile barbe and + hobe 11+1=12 amon hobe seconndery value te
            //secondnum value asbe primary view theke
            secondnum=Double.parseDouble(mainTextview.getText().toString());
            double resultvalue = firstnum+secondnum;
            //= value main view te dekhabo
            mainTextview.setText(""+resultvalue);
            //11+11=22 asle 11+11 opore dekhabe secoundery text view te.
            secondview.setText(""+firstnum+operator+secondnum+"=");
        }
    }*/

    public void btnFunction(View view) {
        //btn er sathe onclick jukto hoi tokon view perameter er sathe property cole ase id o cole ase
        if(view.getId()==R.id.btn1) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("1");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "1");
            }
        }
        else  if(view.getId()==R.id.btn2) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("2");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "2");
            }
        }
        else  if(view.getId()==R.id.btn3) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("3");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "3");
            }
        }
        else  if(view.getId()==R.id.btn4) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("4");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "4");
            }
        }
        else  if(view.getId()==R.id.btn5) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("5");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "5");
            }
        }
        else  if(view.getId()==R.id.btn6) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("6");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "6");
            }
        }
        else  if(view.getId()==R.id.btn7) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("7");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "7");
            }
        }
        else  if(view.getId()==R.id.btn8) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("8");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "8");
            }
        }
        else  if(view.getId()==R.id.btn9) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("9");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "9");
            }
        }
        else  if(view.getId()==R.id.btn0) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String primaryvalue = primaryview.getText().toString();
            //check korlam 0 ki na
            if (primaryvalue.equals("0")) {
                //primary txt view 0 change hoa 1 hbe 0 hole 1 w
                primaryview.setText("0");
            }
            //else jokhon 0 na tokhon set text na kore ager tar sathe add kore dibo
            else {
                primaryview.setText("" + primaryvalue + "0");
            }
        }
        else if(view.getId()==R.id.btnc){

            primaryview.setText("0");
            secondaryview.setText("");
            temp="";
            num1=0;
            num2=0;

        }
        else  if(view.getId()==R.id.btnsum) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String mainprimaryvalue = primaryview.getText().toString();
            operator="+";
            secondaryview.setText(""+mainprimaryvalue+""+operator);
            //+ korar por nice value 0 hoa jabe tar jonno
            num1=Double.parseDouble(mainprimaryvalue);
            primaryview.setText("0");
            //5.0 amon hobe tai temp null
            temp="";

        }
        else  if(view.getId()==R.id.btnsub) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String mainprimaryvalue = primaryview.getText().toString();
            operator="-";
            secondaryview.setText(""+mainprimaryvalue+""+operator);
            //+ korar por nice value 0 hoa jabe tar jonno
            num1=Double.parseDouble(mainprimaryvalue);
            primaryview.setText("0");
            temp="";

        }
        else  if(view.getId()==R.id.btnmulti) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String mainprimaryvalue = primaryview.getText().toString();
            operator="*";
            secondaryview.setText(""+mainprimaryvalue+""+operator);
            //+ korar por nice value 0 hoa jabe tar jonno
            num1=Double.parseDouble(mainprimaryvalue);
            primaryview.setText("0");
            temp="";

        }
        else  if(view.getId()==R.id.btndiv) {
            //jokhon btn click korlam tokon primaryvalue er maddhume primaryvalue er theke string nia aslam then
            String mainprimaryvalue = primaryview.getText().toString();
            operator="/";
            secondaryview.setText(""+mainprimaryvalue+""+operator);
            //+ korar por nice value 0 hoa jabe tar jonno
            num1=Double.parseDouble(mainprimaryvalue);
            primaryview.setText("0");
            temp="";

        }

        /////result er jonno
        else if (view.getId()==R.id.btnresult){
            num2=Double.parseDouble(primaryview.getText().toString());
            if(operator.equals("+"))
            {
                result=num1+num2;
                primaryview.setText(""+result);
                secondaryview.setText(""+num1+""+operator+""+num2+"=");
                primaryview.setText(""+result);
                num1=0;
                num2=0;
                result=0;
                operator="";
            }
            else if(operator.equals("-"))
            {
                result=num1-num2;
                primaryview.setText(""+result);
                secondaryview.setText(""+num1+""+operator+""+num2+"=");
                primaryview.setText(""+result);
                num1=0;
                num2=0;
                result=0;
                operator="";
            }
            else if(operator.equals("*"))
            {
                result=num1*num2;
                primaryview.setText(""+result);
                secondaryview.setText(""+num1+""+operator+""+num2+"=");
                primaryview.setText(""+result);
                num1=0;
                num2=0;
                result=0;
                operator="";
            }
            else
            {
                result=num1/num2;
                primaryview.setText(""+result);
                secondaryview.setText(""+num1+""+operator+""+num2+"=");
                primaryview.setText(""+result);
                num1=0;
                num2=0;
                result=0;
                operator="";
            }
        }
        //.er kaj 0 er pase . uthbe tai .chackng name variable nibo temp
        else{
            if(temp.isEmpty()){
                String mainvalue=primaryview.getText().toString();
                //mainvalue jai hok . tar sathe primaryview. set
                primaryview.setText(mainvalue+".");
                temp="iamfull";
            }

        }



    }
}

