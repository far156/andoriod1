package com.example.lc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;


public class HomePage extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    Spinner mySpinner;
    Fragment myFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        mySpinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> myAdapter = ArrayAdapter.createFromResource(this,R.array.conquerorNames,android.R.layout.simple_spinner_item);
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);
        mySpinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        if(text.equals("Julius Ceaser")){
            myFragment = new JuliusCeaser();
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft=fm.beginTransaction();
            ft.replace(R.id.fragment,myFragment);
            ft.commit();
        }
        else if(text.equals("Alexander The Great")){
            myFragment = new Alexander();
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft=fm.beginTransaction();
            ft.replace(R.id.fragment,myFragment);
            ft.commit();
        }
        else if(text.equals("Saladin")){
            myFragment = new Saladin();
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft=fm.beginTransaction();
            ft.replace(R.id.fragment,myFragment);
            ft.commit();
        }
        else if(text.equals("Richard The Lionheart")){
            myFragment = new Richard();
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft=fm.beginTransaction();
            ft.replace(R.id.fragment,myFragment);
            ft.commit();
        }
        else if(text.equals("Ramses II")){
            myFragment = new Ramses();
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft=fm.beginTransaction();
            ft.replace(R.id.fragment,myFragment);
            ft.commit();
        }
        else{
            myFragment = new Fragment();
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft=fm.beginTransaction();
            ft.replace(R.id.fragment,myFragment);
            ft.commit();
        }
        Toast.makeText(parent.getContext(),text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}