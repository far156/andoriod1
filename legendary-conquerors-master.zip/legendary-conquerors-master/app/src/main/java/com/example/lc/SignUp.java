package com.example.lc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {

    EditText firstName, lastName, password, rePassword, email, birthDate,userName;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        userName = findViewById(R.id.enterUserName);
        firstName=findViewById(R.id.enterName1);
        lastName=findViewById(R.id.enterName2);
        lastName=findViewById(R.id.enterName2);
        password=findViewById(R.id.enterPassword2);
        rePassword=findViewById(R.id.reEnterPassword2);
        email=findViewById(R.id.enterEmail2);
        birthDate=findViewById(R.id.enterBirthDate);
    }

    public void confirmSignUp(View view) {

        String uName = userName.getText().toString();
        String inputEmail = email.getText().toString();
        String inputPassword = password.getText().toString();
        String confirmPassword = rePassword.getText().toString();
        String dob = birthDate.getText().toString();
        String fname= firstName.getText().toString();
        String lname = lastName.getText().toString();

        if (!inputEmail.matches(emailPattern)){
            Toast.makeText(SignUp.this, "Please enter E-mail correctly", Toast.LENGTH_SHORT).show();
        }
        else if(inputPassword.isEmpty() || inputPassword.length()<8)
        {
            Toast.makeText(SignUp.this, "Please enter password correctly", Toast.LENGTH_SHORT).show();
        }
        else if(!inputPassword.matches(confirmPassword))
        {
            Toast.makeText(SignUp.this, "Password didn't match", Toast.LENGTH_SHORT).show();
        }
        else {
            UserInfo user = new UserInfo(fname, lname, inputPassword, dob, inputEmail);
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference root = database.getReference("user");
            root.child(uName).setValue(user);

            Toast.makeText(SignUp.this, "Done!", Toast.LENGTH_SHORT).show();

            Intent intent =  new Intent(SignUp.this,MainActivity.class);
            startActivity(intent);

        }

    }
}